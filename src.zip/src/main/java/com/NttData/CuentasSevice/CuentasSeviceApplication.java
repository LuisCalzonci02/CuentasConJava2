package com.NttData.CuentasSevice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CuentasSeviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CuentasSeviceApplication.class, args);
	}

}
