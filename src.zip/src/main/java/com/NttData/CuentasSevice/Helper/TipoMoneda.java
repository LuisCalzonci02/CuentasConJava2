package com.NttData.CuentasSevice.Helper;

public enum TipoMoneda {
    Dollar, Peso;
}
